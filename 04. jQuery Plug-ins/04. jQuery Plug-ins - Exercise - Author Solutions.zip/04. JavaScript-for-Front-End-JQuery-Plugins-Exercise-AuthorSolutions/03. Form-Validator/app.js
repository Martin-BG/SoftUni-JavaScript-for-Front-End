// $.validate();

$.validate({
    borderColorOnError : '#FFF',
    addValidClassOnAll : true
});